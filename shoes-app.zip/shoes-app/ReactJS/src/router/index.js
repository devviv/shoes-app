import { createBrowserRouter } from "react-router-dom";
import { Banner } from '../components/Banner';

export const router = createBrowserRouter([
     {
        path:'/',
        element: Banner,
        
     }
])

