<?php

namespace App\Http\Controllers;

use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function register(Request $request)
    {
        try {
            $validator = Validator::make(
                $request->all(),
                [
                    "name" => "string|required",
                    "email" => "unique:users,email|required|email",
                    "password" => "string|required",
                ]
            );


            if ($validator->fails()) {
                return response()->json([
                    "status" => "ECHEC",
                    "erreur" => $validator->errors()
                ]);
            }


            // return $request['name'];
            $user = User::create([
                "name" => $request['name'],
                "email" => $request['email'],
                "password" => Hash::make($request['password']),
            ]);


            return response()->json([
                "message" => "Agent routier ajoutée",
                "status" => "SUCCESS",
                "agent_routier" => $user
            ]);
        } catch (Exception $e) {
            return response()->json([
                "message" => "Erreur",
                "status" => "ECHEC",
                "erreur" => $e->getMessage()
            ]);
        }
    }

    public function login(Request $request)
    {
        $validator = Validator::make($request->json()->all(), [
            "email" => "required|email",
            "password" => "required",
        ]);


        // Verifier si la validation a échoué
        if ($validator->fails()) {
            return response()->json([
                "statut" => "ECHEC",
                "errors" => $validator->errors()
            ]);
        }

        $user = User::where('email', $request->json("email"))->first();

        if (!$user) {
            return response()->json([
                "statut" => "ECHEC",
                "errors" => "Votre email est incorrect"
            ]);
        }

        if (Hash::check($request->json("password"), $user->password)) {
            Auth::login($user);
            $token = $user->createToken('userToken')->plainTextToken;

            return response()->json([
                "status" => "SUCCESS",
                "user" => $user,
                "token" => $token
            ]);
        }


        // On retourne l'erreur du mot de passe
        return response()->json([
            "status" => "ECHEC",
            "errors" => "Votre mot de passe est incorrect!"
        ]);
    }
}
